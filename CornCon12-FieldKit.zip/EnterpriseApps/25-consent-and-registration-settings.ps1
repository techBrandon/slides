<#
    Two properties, thirty seconds. These govern who in your tenant can
    create an application and what a user may consent to on their own.

    Note that these describe the tenant's configuration right now.
    They say nothing about what was granted under earlier defaults -
    for that, see 27-user-consented-grants.ps1
#>

Connect-MgGraph -Scopes 'Policy.Read.All'

$p = (Get-MgPolicyAuthorizationPolicy).DefaultUserRolePermissions

# Can any user register an application?
$p.AllowedToCreateApps

# What is a user allowed to consent to alone?
$p.PermissionGrantPoliciesAssigned
