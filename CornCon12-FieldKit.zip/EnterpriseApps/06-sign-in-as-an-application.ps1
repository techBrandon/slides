<#
    Demonstrates client-credentials authentication. Requires an app
    registration you own, its client secret, and your tenant ID.
    Nothing here reads or writes directory data on its own.
#>

$tenantId = '<tenant-guid>'
$appId    = '<app-guid>'
$secret   = ConvertTo-SecureString '<secret>' -AsPlainText -Force
$cred     = [PSCredential]::new($appId, $secret)

Connect-MgGraph -TenantId $tenantId -ClientSecretCredential $cred

# AuthType is AppOnly and Account is empty. There is no user.
Get-MgContext
