<#
    Redirect URIs across all three collections - Web, Spa and
    PublicClient - filtered to the obviously risky ones.

    $Risky catches wildcards, localhost and plaintext http. It cannot
    tell you that a domain lapsed in 2022. For that, set $Risky to '.'
    to return everything, extract the hostnames, resolve them, and
    check which ones you still own. That is the version worth running.
#>

Connect-MgGraph -Scopes 'Application.Read.All'

$Risky = '\*|localhost|^http://'

foreach ($app in Get-MgApplication -All) {
  $uris = @($app.Web.RedirectUris) +
          @($app.Spa.RedirectUris) +
          @($app.PublicClient.RedirectUris)

  foreach ($u in $uris | Where-Object { $_ -match $Risky }) {
    [pscustomobject]@{ App = $app.DisplayName; Uri = $u }
  }
}
