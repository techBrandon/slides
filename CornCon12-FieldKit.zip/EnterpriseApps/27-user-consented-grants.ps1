<#
    Every delegated permission grant in the tenant, of both consent
    types, with the application resolved to a name.

    The User column distinguishes them:
      - a UPN means ConsentType 'Principal'     - one user consented
                                                  for themselves
      - 'ALL USERS (admin consent)' means
        ConsentType 'AllPrincipals'             - an administrator
                                                  consented on behalf
                                                  of the whole tenant

    Principal grants are the archaeology: individual users, often
    years ago, often predating the tenant's current consent settings.
    AllPrincipals grants are deliberate decisions, which makes them
    easier to justify and far wider in blast radius.

    Two lookups per grant makes this slow in a large tenant. Cache the
    service principal and user lookups if you are running it at scale.
#>

Connect-MgGraph -Scopes 'Directory.Read.All'

foreach ($g in Get-MgOauth2PermissionGrant -All) {

  $app = Get-MgServicePrincipal -ServicePrincipalId $g.ClientId

  $who = if ($g.ConsentType -eq 'AllPrincipals') { 'ALL USERS (admin consent)' }
         else { (Get-MgUser -UserId $g.PrincipalId).UserPrincipalName }

  [pscustomobject]@{
    App    = $app.DisplayName
    User   = $who
    Scopes = $g.Scope.Trim()
  }
}
