<#
    Every application credential in the tenant with its computed
    lifetime in years, longest first.

    $MaxYears is set to the portal's ceiling. Anything above that line
    was created through the API deliberately.

    Drop the final Where-Object to also see expired credentials still
    sitting on applications. Those are their own signal: nobody is
    tending that app.

    This covers applications only. Swap Get-MgApplication for
    Get-MgServicePrincipal to catch credentials on service principals
    from multi-tenant apps.
#>

Connect-MgGraph -Scopes 'Application.Read.All'

$MaxYears = 2

$creds = foreach ($app in Get-MgApplication -All) {
  foreach ($c in $app.PasswordCredentials) {
    [pscustomobject]@{
      App     = $app.DisplayName
      Expires = $c.EndDateTime
      Years   = [int][math]::Round(($c.EndDateTime - $c.StartDateTime).TotalDays/365)
    }
  }
}

$creds | Where-Object Years -gt $MaxYears | Sort-Object Years -Descending
