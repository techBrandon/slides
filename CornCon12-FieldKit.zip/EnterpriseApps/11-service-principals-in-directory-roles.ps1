<#
    Lists every service principal holding a directory role assignment,
    with the role resolved to its display name rather than a GUID.
    Anything in the output you did not deliberately put there is a finding.
#>

Connect-MgGraph -Scopes 'RoleManagement.Read.Directory'

$roles    = Get-MgRoleManagementDirectoryRoleDefinition -All
$assigned = Get-MgRoleManagementDirectoryRoleAssignment -All `
                -ExpandProperty Principal

foreach ($a in $assigned) {
    $p    = $a.Principal.AdditionalProperties
    $role = $roles | Where-Object Id -eq $a.RoleDefinitionId

    if ($p.'@odata.type' -notmatch 'servicePrincipal') { continue }

    [pscustomobject]@{ App = $p.displayName; Role = $role.DisplayName }
}
