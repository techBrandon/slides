<#
    READ ONLY. Scope required: Application.Read.All

    Every app-only Microsoft Graph permission granted in the tenant,
    resolved from permission GUIDs to readable names.

    $Dangerous is a starting point, not a standard. Edit it for your
    tenant. On a first run, or in a smaller tenant, drop the final
    Where-Object and read the whole list instead.
#>

$Dangerous = @('RoleManagement.ReadWrite.Directory',
               'AppRoleAssignment.ReadWrite.All',
               'Application.ReadWrite.All')

Connect-MgGraph -Scopes 'Application.Read.All'

# 00000003-0000-0000-c000-000000000000 is Microsoft Graph.
# It is the same value in every tenant.
$graph = Get-MgServicePrincipal -Filter "appId eq '00000003-0000-0000-c000-000000000000'"
$roles = @{}; $graph.AppRoles | ForEach-Object { $roles[$_.Id] = $_.Value }

$all = Get-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $graph.Id -All |
  ForEach-Object {
    [pscustomobject]@{ App = $_.PrincipalDisplayName; Permission = $roles[$_.AppRoleId] }
  }

# Output $all without the Where clause for a full list. This command is a filter.
$all | Where-Object Permission -in $Dangerous | Sort-Object App | Format-Table
