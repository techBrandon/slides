<#
    *** THIS SCRIPT WRITES. It is demo material, not part of the
    *** read-only field kit. Run it only against a lab tenant and an
    *** app registration you own.

    Shows that the portal's credential-lifetime ceiling is a property
    of the portal, not of the API. endDateTime is just a field.

    Requires an existing $appId and permission to add credentials to
    that application.
#>

$end = (Get-Date).AddYears(100)

Add-MgApplicationPassword -ApplicationId $appId `
    -PasswordCredential @{
        displayName = 'ci-pipeline'; endDateTime = $end
    }
